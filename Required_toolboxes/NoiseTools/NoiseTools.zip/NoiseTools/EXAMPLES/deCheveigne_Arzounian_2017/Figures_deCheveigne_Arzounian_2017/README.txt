Scripts to recreate the figures of:
de Cheveign�, A., Arzounian, D., Robust detrending, rereferencing,
outlier detection, and inpainting for multichannel data,(2017, submitted to
NeuroImage).

The scripts require the NoiseTools toolbox that can be downloaded from 
http://audition.ens.fr/adc/NoiseTools/
and data files that can be downloaded from 
http://audition.ens.fr/adc/NoiseTools/DATA/figures_deCheveigne_Arzounian_2017/